This is a simple Django-based REST API for managing applications. The API allows you to:
1) Add new app details (POST /api/add-app)

2) Retrieve app details by ID (GET /api/get-app/{id})

3) Delete an app by ID (DELETE /api/delete-app/{id})

Requirments:
1)Python
2)Django
3)Sql

Start The server with:
python manage.py runserver

The API will be available at: http://127.0.0.1:8000/

Add an App (POST /api/add-app/)
example:
{
  "app_name": "AdStack",
  "version": "6.9",
  "description": "Hello"
}
and then POST
Your App is added

2. Retrieve an App (GET /api/get-app/{id}/)
Your App is Displayed

3. Delete an App (DELETE /api/delete-app/{id})
Your App is Deleted