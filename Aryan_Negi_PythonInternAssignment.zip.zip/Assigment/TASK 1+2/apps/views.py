# Create your views here.

from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view
from .models import AppDetails
from .serializers import AppDetailsSerializer

@api_view(["POST"])
def add_app(request):
    """Add a new app to the database."""
    serializer = AppDetailsSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(["GET"])
def get_app(request, id):
    """Retrieve app details by ID."""
    try:
        app = AppDetails.objects.get(id=id)
        serializer = AppDetailsSerializer(app)
        return Response(serializer.data, status=status.HTTP_200_OK)
    except AppDetails.DoesNotExist:
        return Response({"error": "App not found"}, status=status.HTTP_404_NOT_FOUND)

@api_view(["DELETE"])
def delete_app(request, id):
    """Delete an app by ID."""
    try:
        app = AppDetails.objects.get(id=id)
        app.delete()
        return Response({"message": "App deleted"}, status=status.HTTP_200_OK)
    except AppDetails.DoesNotExist:
        return Response({"error": "App not found"}, status=status.HTTP_404_NOT_FOUND)
