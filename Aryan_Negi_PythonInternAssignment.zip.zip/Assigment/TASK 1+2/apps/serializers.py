from rest_framework import serializers
from .models import AppDetails

class AppDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AppDetails
        fields = "__all__"
