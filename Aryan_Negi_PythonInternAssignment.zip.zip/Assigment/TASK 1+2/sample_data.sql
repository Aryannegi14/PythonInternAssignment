INSERT INTO app (app_name, version, description) VALUES
('AppOne', '1.0.0', 'First sample app'),
('AppTwo', '2.3.1', 'Second test application'),
('AppThree', '1.5.2', 'Another demo application');
