CREATE TABLE app (
    id INTEGER PRIMARY KEY AUTOINCREMENT,  
    app_name TEXT UNIQUE NOT NULL,
    version TEXT NOT NULL,
    description TEXT NOT NULL
);
