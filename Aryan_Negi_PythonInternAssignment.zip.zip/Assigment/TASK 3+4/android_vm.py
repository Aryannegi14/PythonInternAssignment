import subprocess
import time

print("Starting Android VM...")
subprocess.Popen([
    "qemu-system-x86_64", "-enable-kvm", "-m", "2048", "-smp", "2", "-cpu", "host", "-hda", "android-x86_64.qcow2", 
    "-net", "nic", "-net", "user", "-vga", "std"
])

time.sleep(30)

print("Connecting ADB to emulator...")
subprocess.run(["adb", "connect", "127.0.0.1:5555"])
subprocess.run(["adb", "devices"])

print("Retrieving system info...")
system_info = subprocess.check_output(["adb", "shell", "getprop"]).decode()

with open("system_info.txt", "w") as file:
    file.write(system_info)

print("System info saved successfully!")
