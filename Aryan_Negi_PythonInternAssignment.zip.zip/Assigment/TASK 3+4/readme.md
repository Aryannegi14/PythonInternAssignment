# Virtual Android System Simulation

Overview

This project simulates a virtual Android system using Python and QEMU, enabling you to:

- Launch an Android emulator without Android Studio
- Install an APK file
- Retrieve system information

Requirements

- QEMU 
- Android Debug Bridge
- Android-x86 image
- Python 

Install All Requirements


 How to Run

1. Start the Android VM using QEMU
   
   qemu-system-x86_64 -enable-kvm -m 2048 -smp 2 -cpu host -hda android-x86_64.qcow2 -net nic -net user -vga 

2. Connect ADB to the Emulator
   
   adb connect 192.168.x.x:5555 (Replace with actual emulator IP)
   adb devices  

3. Install an APK

   adb install sample_app.apk


4. Retrieve System Information

   adb shell getprop > system_info.txt


Output

- QEMU Android VM launched
- APK installed
- System info logged in `system_info.txt`


Server (server.py)
Starts a TCP server on 127.0.0.1:8080

Waits for incoming connections

Receives Android system data from the client

Logs the received data and sends a success response

Client (client.py)
Reads system info from system_info.txt (collected via ADB)

Creates a TCP connection to the server

Sends the system info as a JSON payload

Receives and prints the server’s response