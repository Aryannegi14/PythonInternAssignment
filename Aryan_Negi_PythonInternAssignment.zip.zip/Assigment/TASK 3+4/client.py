import socket
import json

SERVER_IP = "127.0.0.1"
SERVER_PORT = 8080

# Read system info from file
with open("system_info.txt", "r") as file:
    system_info = file.read()

# Prepare device data
device_data = {
    "device_id": "android_12345",
    "os_version": "Android 11",
    "model": "Pixel 3a",
    "system_info": system_info
}
json_data = json.dumps(device_data)

# Create a TCP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    client_socket.connect((SERVER_IP, SERVER_PORT))
    print(f"Connected to server {SERVER_IP}:{SERVER_PORT}")
    
    client_socket.sendall(json_data.encode())
    print("Data sent:", json_data)
    
    response = client_socket.recv(1024).decode()
    print("Server response:", response)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()

print("Process completed!")
