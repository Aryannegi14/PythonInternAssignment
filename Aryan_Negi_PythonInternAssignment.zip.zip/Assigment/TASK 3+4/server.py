import socket
import json

SERVER_IP = "127.0.0.1"
SERVER_PORT = 8080

# Start the server
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((SERVER_IP, SERVER_PORT))
server_socket.listen(5)

print(f"Server listening on {SERVER_IP}:{SERVER_PORT}...")

while True:
    client_socket, addr = server_socket.accept()
    print(f"Connection from {addr}")

    data = client_socket.recv(4096).decode()
    if not data:
        break

    device_data = json.loads(data)
    print("Received Data:", json.dumps(device_data, indent=4))

    # Send response
    response = "Data received successfully!"
    client_socket.sendall(response.encode())

    client_socket.close()
